/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author MSellami
 */
public class Sector {
    public String SectorName;
    public int IDSector;

    public Sector(String SectorName, int IDSector) {
        this.SectorName = SectorName;
        this.IDSector = IDSector;
    }
    
}
